package com.example.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

private class Tile(val icon: String, val label: String, val enabled: Boolean = true, val onClick: () -> Unit)

class AssistiveService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var floatView: View? = null
    private lateinit var floatLp: WindowManager.LayoutParams
    private var scrim: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var page = "main"

    private var light = false
    private var opacity = 90
    private var sizeDp = 56

    private val parents = mapOf("device" to "main", "more" to "main", "gestures" to "more", "settings" to "more")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val fg get() = if (light) 0xFF17171A.toInt() else Color.WHITE
    private val muted get() = if (light) 0xFF666666.toInt() else 0xFFAAAAAA.toInt()
    private val line get() = if (light) 0x1F000000 else 0x21FFFFFF
    private val panelBg get() = if (light) 0xF5FAFAFC.toInt() else 0xF01E1E21.toInt()
    private val tileBg get() = 0x1A828290

    // ---------- lifecycle ----------

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("at", MODE_PRIVATE)
        light = prefs.getBoolean("light", false)
        opacity = prefs.getInt("opacity", 90)
        sizeDp = prefs.getInt("size", 56)
        showFloat()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        closePanel()
        floatView?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- tombol melayang ----------

    private fun showFloat() {
        floatView?.let { runCatching { wm.removeView(it) } }
        val v = object : View(this) {
            val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = dp(2).toFloat() }
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
            override fun onDraw(c: Canvas) {
                val r = width * 0.22f
                c.drawCircle(width / 2f, height / 2f, r, ring)
                c.drawCircle(width / 2f, height / 2f, r * 0.35f, dot)
            }
        }
        val m = resources.displayMetrics
        floatLp = WindowManager.LayoutParams(
            dp(sizeDp), dp(sizeDp),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", m.widthPixels - dp(sizeDp) - dp(8))
            y = prefs.getInt("y", m.heightPixels / 2)
        }
        v.setOnTouchListener(dragListener())
        wm.addView(v, floatLp)
        floatView = v
        styleFloat()
    }

    private fun styleFloat() {
        floatView?.apply {
            background = GradientDrawable().apply {
                setColor(0x85505055.toInt())
                cornerRadius = dp(sizeDp) * 0.34f
                setStroke(dp(1), 0x59FFFFFF)
            }
            alpha = opacity / 100f
        }
        floatLp.width = dp(sizeDp)
        floatLp.height = dp(sizeDp)
        runCatching { wm.updateViewLayout(floatView, floatLp) }
    }

    private fun dragListener() = object : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = floatLp.x; oy = floatLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (Math.abs(dx) + Math.abs(dy) > dp(7)) moved = true
                    if (moved) {
                        floatLp.x = (ox + dx).toInt(); floatLp.y = (oy + dy).toInt()
                        wm.updateViewLayout(v, floatLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) snapToEdge() else if (scrim == null) openPanel("main") else closePanel()
            }
            return true
        }
    }

    private fun snapToEdge() {
        val m = resources.displayMetrics
        floatLp.x = if (floatLp.x + floatLp.width / 2 < m.widthPixels / 2) dp(8) else m.widthPixels - floatLp.width - dp(8)
        floatLp.y = floatLp.y.coerceIn(0, m.heightPixels - floatLp.height)
        wm.updateViewLayout(floatView, floatLp)
        prefs.edit().putInt("x", floatLp.x).putInt("y", floatLp.y).apply()
    }

    // ---------- panel menu ----------

    private fun openPanel(p: String) {
        closePanel()
        val m = resources.displayMetrics
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = GradientDrawable().apply { setColor(panelBg); cornerRadius = dp(27).toFloat(); setStroke(dp(1), line) }
            isClickable = true
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { closePanel() }
        }
        root.addView(box, FrameLayout.LayoutParams(minOf(dp(330), m.widthPixels - dp(38)), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        scrim = root; panel = box
        render(p)
    }

    private fun closePanel() {
        scrim?.let { runCatching { wm.removeView(it) } }
        scrim = null; panel = null
    }

    private fun render(p: String) {
        val b = panel ?: return
        page = p
        b.removeAllViews()
        when (p) {
            "main" -> {
                b.addView(header("AssistiveTouch"))
                b.addView(grid(listOf(
                    Tile("⌕", "Device") { render("device") },
                    Tile("⌂", "Home") { global(GLOBAL_ACTION_HOME) },
                    Tile("▤", "Notifications") { global(GLOBAL_ACTION_NOTIFICATIONS) },
                    Tile("☷", "Quick Settings") { global(GLOBAL_ACTION_QUICK_SETTINGS) },
                    Tile("▣", "Screenshot") { global(GLOBAL_ACTION_TAKE_SCREENSHOT, Build.VERSION_CODES.P, 400) },
                    Tile("•••", "More") { render("more") }
                )))
            }
            "device" -> {
                b.addView(header("Device"))
                b.addView(grid(listOf(
                    Tile("🔊", "Volume Up") { volume(AudioManager.ADJUST_RAISE) },
                    Tile("🔉", "Volume Down") { volume(AudioManager.ADJUST_LOWER) },
                    Tile("🔇", "Mute") { volume(AudioManager.ADJUST_TOGGLE_MUTE) },
                    Tile("⟳", "Auto-rotate") { toggleRotate() },
                    Tile("🔒", "Lock Screen") { global(GLOBAL_ACTION_LOCK_SCREEN, Build.VERSION_CODES.P) },
                    Tile("⏻", "Power Menu") { global(GLOBAL_ACTION_POWER_DIALOG) }
                )))
            }
            "more" -> {
                b.addView(header("More"))
                b.addView(grid(listOf(
                    Tile("✋", "Gestures") { render("gestures") },
                    Tile("▢", "App Switcher") { global(GLOBAL_ACTION_RECENTS) },
                    Tile("↩", "Back") { global(GLOBAL_ACTION_BACK) },
                    Tile("◐", "Appearance") { toggleTheme() },
                    Tile("⚙", "Settings") { render("settings") },
                    Tile("◉", "Assistant") { openAssistant() }
                )))
            }
            "gestures" -> {
                b.addView(header("Gestures"))
                b.addView(row("Single Tap", "Tengah layar ›") { gesture("tap") })
                b.addView(row("Double Tap", "Tengah layar ›") { gesture("double") })
                b.addView(row("Long Press", "Tengah layar ›") { gesture("long") })
                b.addView(row("Swipe Up", "›") { gesture("up") })
                b.addView(row("Swipe Down", "›") { gesture("down") })
                b.addView(note("Menu ditutup dulu, lalu gesture dikirim ke aplikasi yang sedang terbuka."))
            }
            "settings" -> {
                b.addView(header("Settings"))
                b.addView(slider("Opacity", opacity, 25, 100, "%") { opacity = it; prefs.edit().putInt("opacity", it).apply(); styleFloat() })
                b.addView(slider("Button size", sizeDp, 42, 76, " dp") { sizeDp = it; prefs.edit().putInt("size", it).apply(); styleFloat() })
                b.addView(row("Switch appearance", "Light / Dark") { toggleTheme() })
                b.addView(row("Reset settings", "↺") {
                    opacity = 90; sizeDp = 56; light = false
                    prefs.edit().putInt("opacity", 90).putInt("size", 56).putBoolean("light", false).apply()
                    styleFloat(); openPanel("settings"); toast("Pengaturan direset")
                })
            }
        }
    }

    // ---------- aksi ----------

    private fun global(action: Int, minApi: Int = 0, delayMs: Long = 250) {
        if (Build.VERSION.SDK_INT < minApi) { toast("Fitur ini butuh Android lebih baru"); return }
        closePanel()
        handler.postDelayed({ performGlobalAction(action) }, delayMs)
    }

    private fun volume(dir: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun toggleRotate() {
        if (!Settings.System.canWrite(this)) {
            closePanel()
            toast("Izinkan 'Ubah pengaturan sistem' untuk AssistiveTouch")
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val now = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
        Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1 - now)
        toast(if (now == 0) "Auto-rotate aktif" else "Auto-rotate mati")
    }

    private fun openAssistant() {
        closePanel()
        val tries = listOf(Intent.ACTION_VOICE_COMMAND, Intent.ACTION_ASSIST)
        for (a in tries) {
            if (runCatching { startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
        }
        toast("Asisten suara tidak ditemukan")
    }

    private fun toggleTheme() {
        light = !light
        prefs.edit().putBoolean("light", light).apply()
        openPanel(page)
    }

    private fun gesture(kind: String) {
        closePanel()
        handler.postDelayed({
            val m = resources.displayMetrics
            val cx = m.widthPixels / 2f; val cy = m.heightPixels / 2f
            fun tapStroke(start: Long, dur: Long) =
                GestureDescription.StrokeDescription(Path().apply { moveTo(cx, cy) }, start, dur)
            fun swipe(fromY: Float, toY: Float) =
                GestureDescription.StrokeDescription(Path().apply { moveTo(cx, fromY); lineTo(cx, toY) }, 0, 300)
            val b = GestureDescription.Builder()
            when (kind) {
                "tap" -> b.addStroke(tapStroke(0, 50))
                "double" -> { b.addStroke(tapStroke(0, 50)); b.addStroke(tapStroke(150, 50)) }
                "long" -> b.addStroke(tapStroke(0, 800))
                "up" -> b.addStroke(swipe(cy * 1.4f, cy * 0.6f))
                "down" -> b.addStroke(swipe(cy * 0.6f, cy * 1.4f))
            }
            dispatchGesture(b.build(), null, null)
        }, 250)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- helper UI ----------

    private fun txt(s: String, size: Float, color: Int) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    }

    private fun header(title: String): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(3), 0, dp(3), dp(12))
        if (page != "main") {
            addView(txt("‹", 24f, muted).apply { setPadding(0, 0, dp(12), 0); setOnClickListener { render(parents[page] ?: "main") } })
        }
        addView(txt(title, 14f, fg).apply { gravity = Gravity.START }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (page == "main") addView(txt("×", 22f, muted).apply { setPadding(dp(8), 0, dp(4), 0); setOnClickListener { closePanel() } })
    }

    private fun grid(tiles: List<Tile>): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        tiles.chunked(3).forEach { rowTiles ->
            val r = LinearLayout(this@AssistiveService)
            rowTiles.forEach {
                r.addView(tile(it), LinearLayout.LayoutParams(0, dp(82), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            addView(r)
        }
    }

    private fun tile(t: Tile): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = GradientDrawable().apply { setColor(tileBg); cornerRadius = dp(17).toFloat(); setStroke(dp(1), line) }
        alpha = if (t.enabled) 1f else 0.35f
        addView(txt(t.icon, 23f, fg))
        addView(txt(t.label, 11f, fg).apply { setPadding(0, dp(6), 0, 0) })
        if (t.enabled) setOnClickListener { t.onClick() }
    }

    private fun row(label: String, hint: String, onClick: () -> Unit): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(13), dp(12), dp(13))
        background = GradientDrawable().apply { setColor(tileBg); cornerRadius = dp(13).toFloat(); setStroke(dp(1), line) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) }
        addView(txt(label, 14f, fg).apply { gravity = Gravity.START }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(txt(hint, 12f, muted))
        setOnClickListener { onClick() }
    }

    private fun note(s: String): View = txt(s, 11f, muted).apply { gravity = Gravity.START; setPadding(dp(3), dp(10), dp(3), dp(2)) }

    private fun slider(label: String, value: Int, min: Int, max: Int, unit: String, onChange: (Int) -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(10), dp(4), dp(6))
            val head = LinearLayout(this@AssistiveService)
            val valueTv = txt("$value$unit", 13f, muted)
            head.addView(txt(label, 13f, fg).apply { gravity = Gravity.START }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(valueTv)
            addView(head)
            addView(SeekBar(this@AssistiveService).apply {
                this.min = min; this.max = max; progress = value
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                        if (fromUser) { valueTv.text = "$p$unit"; onChange(p) }
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            })
        }
}
